package com.hss;

public class Car {

}
