package com.hss;

import org.springframework.data.repository.CrudRepository;

public interface CarDao extends CrudRepository<Car, Integer> {

}
