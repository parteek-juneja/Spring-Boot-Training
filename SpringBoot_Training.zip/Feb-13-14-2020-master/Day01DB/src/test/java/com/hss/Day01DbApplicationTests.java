package com.hss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day01DbApplicationTests {

	@Test
	void contextLoads() {
	}

}
