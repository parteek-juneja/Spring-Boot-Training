package com.hss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab04PalindromeApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab04PalindromeApplication.class, args);
	}

}
